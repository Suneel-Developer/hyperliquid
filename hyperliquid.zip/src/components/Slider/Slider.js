import React, { useState } from "react";

const Slider = () => {
  const [range, setRange] = useState(0);

  const handleRangeChange = (event) => {
    setRange(event.target.value);
  };
  return (
    <div className="mx-auto items-center justify-center flex">
      <div className="w-full mx-auto  items-center justify-center flex gap-2">
        <div className=" w-full mx-auto">
          <div className="relative">
            <div className="w-full flex gap-2 items-center py-6">
              <input
                type="range"
                min="0"
                max="100"
                className="w-full  z-20"
                value={range}
                onChange={handleRangeChange}
              />
            </div>
            <div className="absolute top-6 items-center transform -translate-y-1/2 h-7  z-0 left-0 flex text-[#50d2c1] justify-between text-[7px] w-full">
              <span>|</span>
              <span>|</span>
              <span>|</span>
              <span>|</span>
              <span>|</span>
            </div>
          </div>
        </div>
        <p
          className="text-center w-20 flex justify-between rounded px-2 py-1 border text-white border-dark_100"
          id="rangeValue "
        >
          <span> {range}</span>
          <span>%</span>
        </p>
      </div>
    </div>
  );
};

export default Slider;
