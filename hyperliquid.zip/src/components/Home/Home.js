import React, { useState } from "react";
import "./home.css";
import EnableTrading from "../EnableTrading/EnableTrading";
import Slider from "../Slider/Slider";
import Deposit from "../Deposit/Deposit";
import Withdraw from "../Withdraw/Withdraw";

const Home = () => {
  const [activeTab, setActiveTab] = useState(0);

  const handleTabClick = (index) => {
    setActiveTab(index);
  };
  const [activeSubTab, setActiveSubTab] = useState(0);

  const handleSubTabClick = (index) => {
    setActiveSubTab(index);
  };

  const [range, setRange] = useState(0);

  const handleRangeChange = (event) => {
    setRange(event.target.value);
  };
  return (
    <div className="box-container">
      <div className="flex items-center justify-center gap-4 mx-3 w-[92%] mb-4">
        <button className="bg-dark hover:bg-dark_100 transition duration-300 w-full rounded py-1 px-2 h-[30px] text-xs">
          Cross
        </button>
        <button className="bg-dark hover:bg-dark_100 transition duration-300 w-full rounded py-1 px-2 h-[30px] text-xs">
          20x
        </button>
        <button className="bg-dark hover:bg-dark_100 transition duration-300 w-full rounded py-1 px-2 h-[30px] text-xs">
          One-Way
        </button>
      </div>
      {/* Tabs */}
      <div className="max-w-md mx-auto">
        {/* Tab Buttons */}
        <div className="flex border-b-2 items-center justify-around gap-10 border-dark_400">
          <button
            className={`py-2 text-sm w-full ${
              activeTab === 0
                ? " border-b  border-dark_300  text-dark_500"
                : "text-dark_600"
            }`}
            onClick={() => handleTabClick(0)}
          >
            Market
          </button>
          <button
            className={`py-2 text-sm w-full ${
              activeTab === 1
                ? " border-b  border-dark_300  text-dark_500"
                : "text-dark_600"
            }`}
            onClick={() => handleTabClick(1)}
          >
            Limit
          </button>
          <button
            className={` py-2 text-sm w-full ${
              activeTab === 2
                ? " border-b  border-dark_300  text-dark_500"
                : "text-dark_600"
            }`}
            onClick={() => handleTabClick(1)}
          >
            Pro
          </button>
        </div>
        {/* Tab Content */}
        <div className="mt-4 px-2">
          {activeTab === 0 && (
            <div>
              {/* buttons */}
              <div className="px-1 flex items-center justify-between bg-dark_700 p-1 rounded border border-border_color_100 w-full">
                <button
                  className={` text-black w-1/2 rounded text-sm py-1.5 ${
                    activeSubTab === 0
                      ? "bg-dark_800 text-black"
                      : "text-dark_500"
                  }`}
                  onClick={() => handleSubTabClick(0)}
                >
                  Buy / Long
                </button>
                <button
                  className={` text-black w-1/2 rounded text-sm py-1.5 ${
                    activeSubTab === 1
                      ? " bg-dark_1000 text-white"
                      : "text-dark_500"
                  }`}
                  onClick={() => handleSubTabClick(1)}
                >
                  Sell / Short
                </button>
              </div>
              <div className="grid grid-cols-[1fr,auto] gap-1 items-center py-3 mx-2">
                <h3 className="text-dark_200 font-normal text-sm">
                  Available to Trade
                </h3>
                <h3 className="text-white font-normal text-sm text-right">
                  0.00
                </h3>
                <h3 className="text-dark_200 font-normal text-sm">
                  Current Position
                </h3>
                <h3 className="text-white font-normal text-sm text-right">
                  0.0000 ETH
                </h3>
              </div>
              {/* Select Option */}
              <div className="border border-border_color flex items-center w-full hover:border-dark_900 justify-between rounded py-1.5 px-2.5">
                <h3 className="text-dark_600 text-sm">Size</h3>
                <div className="text-sm">
                  <select className="bg-transparent outline-none border-none">
                    <option className="bg-dark_1400 text-white border-none">
                      ETH
                    </option>
                    <option className="bg-dark_1400 border-none text-white">
                      USD
                    </option>
                  </select>
                </div>
              </div>
              {/* Slider */}
              <div className="mx-auto items-center justify-center flex">
                <div className="w-full mx-auto  items-center justify-center flex gap-2">
                  <div className=" w-full mx-auto">
                    <div className="relative">
                      <div className="w-full flex gap-2 items-center py-6">
                        <input
                          type="range"
                          min="0"
                          max="100"
                          className="w-full  z-20"
                          value={range}
                          onChange={handleRangeChange}
                        />
                      </div>

                      <div className="absolute top-6 items-center transform -translate-y-1/2 h-7  z-0 left-0 flex text-[#50d2c1] justify-between text-[7px] w-full">
                        <span>|</span>
                        <span>|</span>
                        <span>|</span>
                        <span>|</span>
                        <span>|</span>
                      </div>
                    </div>
                  </div>
                  <p
                    className="text-center w-20 flex justify-between rounded px-2 py-1 border text-white border-dark_100"
                    id="rangeValue "
                  >
                    <span> {range}</span>
                    <span>%</span>
                  </p>
                </div>
              </div>
              {/* Checkbox */}
              <div className="text-sm flex flex-col gap-2 my-2">
                <div className="flex items-center gap-2">
                  <div class="checkbox-wrapper-48">
                    <label>
                      <input type="checkbox" name="cb" />
                    </label>
                  </div>
                  <h4 className="text-sm">Reduce Only</h4>
                </div>
                <div className="flex items-center gap-2">
                  <div class="checkbox-wrapper-48">
                    <label>
                      <input type="checkbox" name="cb" />
                    </label>
                  </div>
                  <h4 className="text-sm">Take Profit / Stop Loss</h4>
                </div>
              </div>
              <div className="flex flex-col gap-3">
                <div className="flex gap-3 w-full">
                  <input
                    type="number"
                    placeholder="TP Price"
                    className="bg-transparent border-2 rounded border-border_color w-[60%] outline-none p-2"
                  />
                  <div className="w-[40%] flex gap-14 border-2 rounded border-border_color">
                    <p className="pl-2 mt-[7px] text-dark_200">Gain</p>
                    <div className="select-wrapper w-full mt-1 flex items-center ">
                      <select className="bg-transparent mb-1 border-none outline-none w-full rounded select-arrow">
                        <option value="1" className="bg-dark_1400">
                          %
                        </option>
                        <option value="2" className="bg-dark_1400">
                          $
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 w-full">
                  <input
                    type="number"
                    placeholder="SL Price"
                    className="bg-transparent border-2 rounded border-border_color w-[60%] outline-none p-2"
                  />
                  <div className="w-[40%] flex gap-14 border-2 rounded border-border_color">
                    <p className="pl-2 mt-[7px] text-dark_200">Loss</p>
                    <div className="select-wrapper w-full mt-1 flex items-center ">
                      <select className="bg-transparent mb-1 border-none outline-none w-full rounded select-arrow">
                        <option value="1" className="bg-dark_1400">
                          %
                        </option>
                        <option value="2" className="bg-dark_1400">
                          $
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          {activeTab === 1 && (
            <div>
              {/* buttons */}
              <div className="px-1 flex items-center justify-between bg-dark_700 p-1 rounded border border-border_color_100 w-full">
                <button
                  className={` text-black w-1/2 rounded text-sm py-1.5 ${
                    activeSubTab === 0
                      ? "bg-dark_800 text-black"
                      : "text-dark_500"
                  }`}
                  onClick={() => handleSubTabClick(0)}
                >
                  Buy / Long
                </button>
                <button
                  className={` text-black w-1/2 rounded text-sm py-1.5 ${
                    activeSubTab === 1
                      ? " bg-dark_1000 text-white"
                      : "text-dark_500"
                  }`}
                  onClick={() => handleSubTabClick(1)}
                >
                  Sell / Short
                </button>
              </div>
              <div className="grid grid-cols-[1fr,auto] gap-1 items-center py-3 mx-2">
                <h3 className="text-dark_200 font-normal text-sm">
                  Available to Trade
                </h3>
                <h3 className="text-white font-normal text-sm text-right">
                  0.00
                </h3>
                <h3 className="text-dark_200 font-normal text-sm">
                  Current Position
                </h3>
                <h3 className="text-white font-normal text-sm text-right">
                  0.0000 ETH
                </h3>
              </div>
              {/* Select Option */}
              <div className="border border-border_color flex mb-2 items-center w-full hover:border-dark_900 justify-between rounded py-1.5 px-2.5">
                <h3 className="text-dark_600 text-sm">Price (USD)</h3>
                <p className="text-sm">
                  3765.3{" "}
                  <button className="text-dark_1100 hover:text-dark_1200 ml-1">
                    Mid
                  </button>{" "}
                </p>
              </div>
              <div className="border border-border_color flex items-center w-full hover:border-dark_900 justify-between rounded py-1.5 px-2.5">
                <h3 className="text-dark_600 text-sm">Size</h3>
                <div className="text-sm">
                  <select className="bg-transparent outline-none border-none">
                    <option className="bg-dark_1400 text-white border-none">
                      ETH
                    </option>
                    <option className="bg-dark_1400 border-none text-white">
                      USD
                    </option>
                  </select>
                </div>
              </div>
              {/* Slider */}
              <Slider />
              {/* Checkbox */}
              <div className="text-sm flex flex-col gap-2 my-2 w-full">
                <div className="flex items-center gap-2 justify-between w-full">
                  <div className="flex items-center gap-2">
                    <div class="checkbox-wrapper-48">
                      <label>
                        <input type="checkbox" name="cb" />
                      </label>
                    </div>
                    <h4 className="text-sm">Reduce Only</h4>
                  </div>
                  <div className="flex items-center gap-1 mr-2">
                    <h2 className="text-dark_600 text-sm">TIF</h2>
                    <div className="text-sm">
                      <select className="bg-transparent outline-none border-none text-sm">
                        <option className="bg-dark_1400 text-white border-none">
                          GTC
                        </option>
                        <option className="bg-dark_1400 border-none text-white">
                          IOC
                        </option>
                        <option className="bg-dark_1400 border-none text-white">
                          ALO
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div class="checkbox-wrapper-48">
                    <label>
                      <input type="checkbox" name="cb" />
                    </label>
                  </div>
                  <h4 className="text-sm">Take Profit / Stop Loss</h4>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* Enable Trading */}
      <div className="border border-t border-border_color w-full mt-16 my-3"></div>
      <div className="grid grid-cols-[1fr,auto] gap-2 items-center mx-2">
        <h3 className="text-dark_200 underline font-normal text-sm">
          Liquidation Price
        </h3>
        <h3 className="text-white font-normal text-sm text-right">N/A</h3>
        <h3 className="text-dark_200 font-normal text-sm">Order Value</h3>
        <h3 className="text-white font-normal text-sm text-right">N/A</h3>
        <h3 className="text-dark_200 font-normal text-sm">Margin Required</h3>
        <h3 className="text-white font-normal text-sm text-right">N/A</h3>
        <h3 className="text-dark_200 underline font-normal text-sm">
          Slippage
        </h3>
        <h3 className="text-dark_300 font-normal text-sm">Est: 0% / Max: 8%</h3>
        <h3 className="text-dark_200 underline font-normal text-sm">Fees</h3>
        <h3 className="text-white font-normal text-sm">0.025% / -0.002%</h3>
      </div>
      {/* Enable Treding Button */}
      <EnableTrading />
      {/* buttons withdraw and deposit */}
      <div className="flex flex-col gap-3">
        <div className="border border-t border-border_color w-full"></div>
        <h2 className="text-white text-sm font-normal mx-2">Account</h2>
        <Deposit />
        <Withdraw />
      </div>
      {/* Details */}
      <div className="border border-t border-border_color my-4 mx-2"></div>
      <div className="grid grid-cols-[1fr,auto] gap-2 items-center mx-2">
        <h3 className="text-dark_200 underline font-normal text-sm">Balance</h3>
        <h3 className="text-white font-normal text-sm">$0.00</h3>
        <h3 className="text-dark_200 font-normal text-sm">Unrealized PNL</h3>
        <h3 className="text-white font-normal text-sm">$0.00</h3>
        <h3 className="text-dark_200 underline font-normal text-sm">
          Account Equity
        </h3>
        <h3 className="text-white font-normal text-sm">$0.00</h3>
        <h3 className="text-dark_200 underline font-normal text-sm">
          Cross Margin Ratio
        </h3>
        <h3 className="text-dark_300 font-normal text-sm">$0.00</h3>
        <h3 className="text-dark_200 underline font-normal text-sm">
          Maintenance Margin
        </h3>
        <h3 className="text-white font-normal text-sm">$0.00</h3>
        <h3 className="text-dark_200 underline font-normal text-sm">
          Cross Account Leverage
        </h3>
        <h3 className="text-white font-normal text-sm">$0.00</h3>
      </div>
    </div>
  );
};

export default Home;
